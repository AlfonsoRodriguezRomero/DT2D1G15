
package domain;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Access(AccessType.PROPERTY)
public class MatchRequest extends DomainEntity {

	//Atributes
	private String		status;
	private Integer		row;
	private Integer		column;
	private String		rejectedCause;

	private Member		member;
	private Procession	procession;


	//Getters & Setters
	@NotNull
	@Pattern(regexp = "^(PENDING|APPROVED|REJECTED)$")
	public String getStatus() {
		return this.status;
	}
	public void setStatus(final String status) {
		this.status = status;
	}
	@NotNull
	@Min(0)
	public Integer getRow() {
		return this.row;
	}
	public void setRow(final Integer row) {
		this.row = row;
	}
	@NotNull
	@Min(0)
	public Integer getColumn() {
		return this.column;
	}
	public void setColumn(final Integer column) {
		this.column = column;
	}
	@NotBlank
	public String getRejectedCause() {
		return this.rejectedCause;
	}
	public void setRejectedCause(final String rejectedCause) {
		this.rejectedCause = rejectedCause;
	}

	//Relationships
	@ManyToOne(optional = false)
	public Member getMember() {
		return this.member;
	}
	public void setMember(final Member member) {
		this.member = member;
	}
	@ManyToOne(optional = false)
	public Procession getProcession() {
		return this.procession;
	}
	public void setProcession(final Procession procession) {
		this.procession = procession;
	}
}
