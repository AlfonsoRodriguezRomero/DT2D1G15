
package domain;

import java.util.Collection;

import javax.persistence.Access;
import javax.persistence.AccessType;
import javax.persistence.Entity;
import javax.persistence.ManyToMany;

@Entity
@Access(AccessType.PROPERTY)
public class Member extends Actor {

	//Atributes
	private Collection<Brotherhood>	brotherhoods;


	//Relationships
	@ManyToMany
	public Collection<Brotherhood> getBrotherhoods() {
		return this.brotherhoods;
	}
	public void setBrotherhoods(final Collection<Brotherhood> brotherhoods) {
		this.brotherhoods = brotherhoods;
	}
}
