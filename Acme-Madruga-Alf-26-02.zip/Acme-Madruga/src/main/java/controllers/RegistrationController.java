/*
 * CustomerController.java
 * 
 * Copyright (C) 2018 Universidad de Sevilla
 * 
 * The use of this project is hereby constrained to the conditions of the
 * TDG Licence, a copy of which you may download from
 * http://www.tdg-seville.info/License.html
 */

package controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import services.RegistrationService;
import forms.Registration;

@Controller
@RequestMapping("/customer")
public class RegistrationController extends AbstractController {

	@Autowired
	RegistrationService	registrationService;


	// Constructors -----------------------------------------------------------

	public RegistrationController() {
		super();
	}

	// Action-1 ---------------------------------------------------------------		

	@RequestMapping(value = "/registers", method = RequestMethod.POST, params = "save")
	public ModelAndView save(final RegistrationForm registrationForm, final BindingResult binding) {
		ModelAndView result;
		Registration registration;

		registration = this.registrationService.reconstruct(registrationForm, binding);
		if (binding.hasErrors())
			result = createEditModelAndView(registration);
		else
			try {
				this.registrationService.save(registration);
				result = new ModelAndView("redirect:http://localhost:8080/Acme-Madruga");
			} catch (final Throwable oops) {
				result = createEditModelAndView(registrationForm, "registration.commit.error");
			}

		return result;
	}
	// Action-2 ---------------------------------------------------------------		

	@RequestMapping("/action-2")
	public ModelAndView action2() {
		ModelAndView result;

		result = new ModelAndView("customer/action-2");

		return result;
	}
}
